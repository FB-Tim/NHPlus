CREATE TRIGGER prevent_archive_changes
    BEFORE UPDATE ON archive
    FOR EACH ROW
    BEGIN
        SELECT RAISE(ABORT, 'Archivierte Daten sind unveränderlich');
    END;

